<?php
/**
* Mod borrar inspectores
*
* PHP version 5
*
* @category Mod
* @package  Handy-q
* @author   JJuan <javier@textblock.org>
* @license  http://www.gnu.org/copyleft/gpl.html GNU General Public License
* @link     http://www.textblock.org
*/
?>

<form name="frmMain" action="?seccion=checkbox2_inspectores"
	method="post" OnSubmit="return onDelete();">
	<?php
        $strSQL = "SELECT * FROM inspectores";
        $objQuery = mysqli_query($mysqli, $strSQL) or die ("Error Query ['.$strSQL.']");
?>

	<?php echo GENERAL_DELETE_ADVERTICE; ?>
	<table class="sortable">
		<caption>
			<?php echo BORRAR_INSPECTOR; ?>
		</caption>
		<tbody>
			<tr>
				<!--<th>ID</font></th>-->
				<th><?php echo INSPECCIONES_INSPECTOR; ?></th>
				<th><?php echo GENERAL_ESTADO; ?></th>
				<th><a href="#" title="<?php echo EDITAR_INSPECTOR; ?>">
					<i class="fa fa-edit fa-2x" style="color:Darkorange;"></i>
				</th>
				<th><a href="#" title="<?php echo IMPRIMIR_INSPECTOR; ?>">
					<i class="fa fa-print fa-2x" style="color:Darkorange;"></i>
				</th>
				<th>
				<input name="CheckAll" type="checkbox" id="CheckAll"
					value="Y" onClick="ClickCheckAll(this);">
				</th>
			</tr>

			<?php
        $i = 0;
while ($objResult = mysqli_fetch_array($objQuery)) {
        $i++;
        ?>

			<tr>
				<!--<td><?php echo $objResult['id'];?></td>-->
				<td><?php echo $objResult['inspector'];?></td>
				<td><?php echo $objResult['activo'];?></td>
				<td>
					<a href="?seccion=inspectores_admin&amp;aktion=change_id&amp;id=<?php echo $objResult['id'];?>" 
						title="<?php echo EDITAR_INSPECTOR;?> - <?php echo $objResult['inspector'];?>">
							<i class="fa fa-pencil fa-2x" style="color:Darkorange;"></i>
					</a>
				</td>
				<td><a
					href="?seccion=inspectores_print&amp;aktion=print_id&amp;id=<?php echo $objResult['id'];?>"
					title="<?php echo IMPRIMIR_INSPECTOR;?> - <?php echo $objResult['inspector'];?>">
						<i class="fa fa-print fa-2x" style="color:Darkorange;"></i>
					</a>
				</td>
				<td><input type="checkbox" name="chkDel[]"
					id="chkDel<?php echo $i;?>" value="<?php echo $objResult['id'];?>"></td>
			</tr>
			<?php
}
        ?>
		</tbody>
	</table>
	<input type="submit" name="btnDelete"
		value="<?php echo GENERAL_BORRAR; ?>"> <input type="hidden"
		name="hdnCount" value="<?php echo $i;?>">
</form>
