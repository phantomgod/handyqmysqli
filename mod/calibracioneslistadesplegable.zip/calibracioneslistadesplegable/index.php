<!DOCTYPE html>
<html>
<head>
<title>Consulta de datos</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="JavaScript" type="text/javascript" src="ajax.js"></script>
<link type="text/css" rel="stylesheet" href="../../mod/aisgclistadesplegable/style.css" media="screen" />
</head>
<body>
<p>Seleccione una calibración.</p>
<form name="formulario" action="">
<?php
    include('lista.php');
?>
</form>
<div id="resultado">
</div>
</body>
</html>
