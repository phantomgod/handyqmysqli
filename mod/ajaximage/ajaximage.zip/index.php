<?php
include('../../includes/mysql.php');
session_start();
$session_id='1'; //$session id
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<script type="text/javascript" src="scripts/jquery.min.js"></script>
<script type="text/javascript" src="scripts/jquery.form.js"></script>

<script type="text/javascript" >
 $(document).ready(function() { 
        
            $('#photoimg').live('change', function()            { 
                       $("#preview").html('');
                $("#preview").html('<img src="loader.gif" alt="Uploading...."/>');
            $("#imageform").ajaxForm({
                        target: '#preview'
        }).submit();
        
            });
        }); 
</script>

<style type="text/css">

body
{
height: 100%;
margin: 0px;
padding: 20px;
font-family:arial;
text-indent:25px;
}
.preview
{

width:200px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{

color:#cc0000;
font-size:12px;
text-indent:25px;
}

.div1 {
height: 50%;
width:250px;
background: rgba(70, 109, 230, 0.5);
-pie-background:  rgba(120, 18, 230, 0.5);
-webkit-box-shadow: #666 5px 5px 10px;
-moz-box-shadow: #666 5px 5px 10px;
box-shadow: #666 5px 5px 10px;
behavior: url(pie/PIE.htc);
padding: 10px 10px;
-moz-border-radius: 15px 15px 5px;
-webkit-border-radius: 15px 15px 5px;
font-family: Verdana;
color: rgb(255,255,255);
font-size: 12px;
font-weight: bold;
}

</style>


</head>
<body>
<br />

<div style="width:450px">

<form id="imageform" method="post" enctype="multipart/form-data" action='ajaximage.php'>
<input type="file" name="photoimg" id="photoimg" />
</form>
<br />
Suba una imagen, en el caso de añadir un nuevo perfil, <br /> o actualizarlo.
<div id='preview'>
</div>
<br /><br />

<div class='div1'>UPLOAD PHOTO

<br /><br />
<img src ="uploads/skeleton10.png" height="200px" /></div>


</div>
</body>
</html>