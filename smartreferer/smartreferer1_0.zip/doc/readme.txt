$Id: readme.txt,v 1.1 2004/07/20 11:58:12 jfenin Exp $

README
======

1. What is it?

Smartreferer is a simple set of PHP files to display the refering pages of visitors of a website. It can also display the visitors' user agent strings.


2. What it is not

Smartreferer IS NOT a big web statistics package. It does not provide all information about a user that is available.


3. What do you need?

- a webserver (or webspace) with PHP 4+ enabled
- a MySQL database 3+ 


4. Author, Information

This file is written by Joerg Fenin (joerg AT fenin DOT de).

This file is being published under the GNU public license (GPL) - see license.txt

For support, new versions, info around Smartreferer visit

        http://scripts.fenin.de
        
        





